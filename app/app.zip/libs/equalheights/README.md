# jQuery plugin to equalize heights of multiple elements on a page.

A simple jQuery plugin to keep elements the same height, supporting responsive layouts.

Usage
---
$('.element').equalHeights();